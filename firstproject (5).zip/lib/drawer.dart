import 'package:flutter/material.dart';

class MyDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(padding: EdgeInsets.zero, children: <Widget>[
        UserAccountsDrawerHeader(
          accountName: Text("Muhammad Nabil"),
          accountEmail: Text("mohammad.nabil.ashraf@gmail.com"),
          currentAccountPicture: CircleAvatar(
            backgroundColor: Colors.green[800],
            child: Text(
              "N",
              style: TextStyle(fontSize: 40.0),
            ),
          ),
        ),
        ListTile(
          leading: Icon(Icons.person),
          title: Text('Account'),
          subtitle: Text('Personal'),
          trailing: Icon(Icons.edit),
          onTap: () {
            // Update the state of the app.
            // ...
          },
        ),
        ListTile(
          leading: Icon(Icons.email),
          title: Text('Email'),
          subtitle: Text('mohammad.nabil.ashraf@gmail.com'),
          trailing: Icon(Icons.send),
          onTap: () {
            // Update the state of the app.
            // ...
          },
        ),
      ]),
    );
  }
}
